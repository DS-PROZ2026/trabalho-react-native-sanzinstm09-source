import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Animated,
  Dimensions,
  ImageBackground
} from 'react-native';

const { width, height } = Dimensions.get('window');

export default function App() {
  const [expressao, setExpressao] = useState('');
  const [resultado, setResultado] = useState('0');

const bats = [
  useRef(new Animated.ValueXY({ x: 20,  y: height + 800 })).current,
  useRef(new Animated.ValueXY({ x: 60,  y: height + 1200 })).current,
  useRef(new Animated.ValueXY({ x: 100, y: height + 5000})).current,
  useRef(new Animated.ValueXY({ x: 150, y: height + 15000 })).current,
  useRef(new Animated.ValueXY({ x: 210, y: height + 9000 })).current,
  useRef(new Animated.ValueXY({ x: 260, y: height + 1300})).current,
  useRef(new Animated.ValueXY({ x: 320, y: height + 7080})).current,
  useRef(new Animated.ValueXY({ x: 40,  y: height + 18088})).current,
  useRef(new Animated.ValueXY({ x: 180, y: height + 1333})).current,
  useRef(new Animated.ValueXY({ x: 280, y: height + 1500})).current,
  useRef(new Animated.ValueXY({ x: 340, y: height + 4000 })).current,
];
      
  

  const animarMorcegos = () => {
    bats.forEach((bat, i) => {
      bat.setValue({
        x: -100 - (i * 50),
        y: height * (0.15 + i * 0.1)
      });
    });

    Animated.parallel(
      bats.map((bat, i) =>
        Animated.timing(bat, {
          toValue: {
            x: width + 100,
            y: height * (0.1 + (Math.random() * 0.7))
          },
          duration: 1000 + i * 200,
          useNativeDriver: false
        })
      )
    ).start();
  };

  const calcular = () => {
    try {
      const limpa = expressao.replace(/×/g, '*').replace(/÷/g, '/');
      const valor = eval(limpa);
      setResultado(String(valor));
      animarMorcegos();
    } catch {
      setResultado('Erro');
    }
  };

  const apertar = (tecla) => {
    if (tecla === 'C') {
      setExpressao('');
      setResultado('0');
      return;
    }

    if (tecla === '⌫') {
      setExpressao(expressao.slice(0, -1));
      return;
    }

    if (tecla === '=') {
      calcular();
      return;
    }

    setExpressao(expressao + tecla);
  };

  const teclado = [
    ['C', '⌫', '÷', '×'],
    ['7', '8', '9', '-'],
    ['4', '5', '6', '+'],
    ['1', '2', '3', '.'],
    ['0', '=']
  ];

  const tipoBotao = (t) => {
    if (t === '=') return styles.igual;
    if (t === 'C' || t === '⌫') return styles.limpar;
    if (['+', '-', '×', '÷'].includes(t)) return styles.operador;
    return styles.numero;
  };

  return (
    <ImageBackground
      source={{
        uri: 'https://i.pinimg.com/736x/be/4b/d1/be4bd1d81923974bf8c52e72619b5a4b.jpg'
      }}
      style={styles.background}
      resizeMode="cover"
    >
      <View style={styles.overlay} />

      {bats.map((bat, index) => (
        <Animated.Text
          key={index}
          style={[
            styles.bat,
            {
              left: bat.x,
              top: bat.y
            }
          ]}
        >
          🦇
        </Animated.Text>
      ))}

      <View style={styles.container}>

        <Text style={styles.logo}>BATCAVE SYSTEM</Text>

        <View style={styles.display}>
          <Text style={styles.expressao}>
            {expressao || '0'}
          </Text>

          <Text style={styles.resultado}>
            {resultado}
          </Text>
        </View>

        <View style={styles.keyboard}>
          {teclado.map((linha, i) => (
            <View key={i} style={styles.row}>
              {linha.map((item) => (
                <TouchableOpacity
                  key={item}
                  style={[
                    styles.button,
                    tipoBotao(item),
                    item === '0' && styles.zeroButton
                  ]}
                  onPress={() => apertar(item)}
                  activeOpacity={0.8}
                >
                  <Text style={styles.buttonText}>{item}</Text>
                </TouchableOpacity>
              ))}
            </View>
          ))}
        </View>

      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({

  background: {
    flex: 1
  },

  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(25,0,0,0.65)'
  },

  container: {
    flex: 1,
    paddingTop: 45,
    paddingBottom: 20,
    paddingHorizontal: 14,
    justifyContent: 'space-between'
  },

  logo: {
    color: '#ef4444',
    textAlign: 'center',
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: 3,
    textShadowColor: '#ef4444',
    textShadowRadius: 12
  },

  display: {
    minHeight: height * 0.23,
    backgroundColor: 'rgba(25,5,5,0.92)',
    borderRadius: 25,
    padding: 24,
    justifyContent: 'flex-end',
    borderWidth: 2,
    borderColor: '#ef4444',
    shadowColor: '#ef4444',
    shadowRadius: 15
  },

  expressao: {
    color: '#fca5a5',
    fontSize: 24,
    textAlign: 'right'
  },

  resultado: {
    color: '#ffffff',
    fontSize: 58,
    fontWeight: 'bold',
    textAlign: 'right',
    marginTop: 10
  },

  keyboard: {
    gap: 12
  },

  row: {
    flexDirection: 'row',
    gap: 12
  },

  button: {
    flex: 1,
    height: 82,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 22
  },

  numero: {
    backgroundColor: '#1c1917'
  },

  operador: {
    backgroundColor: '#7f1d1d'
  },

  limpar: {
    backgroundColor: '#450a0a'
  },

  igual: {
    backgroundColor: '#dc2626'
  },

  zeroButton: {
    flex: 2
  },

  buttonText: {
    color: 'white',
    fontSize: 30,
    fontWeight: '800'
  },

  bat: {
    position: 'absolute',
    fontSize: 34,
    zIndex: 1000
  }

});