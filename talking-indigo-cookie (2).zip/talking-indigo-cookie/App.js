import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Animated,
  Dimensions,
  ImageBackground
} from 'react-native';

const { height } = Dimensions.get('window');

export default function App() {
  const [expressao, setExpressao] = useState('');
  const [resultado, setResultado] = useState('0');
  const [tema, setTema] = useState('azul');

  const temas = {
    azul: {
      logo: '#38bdf8',
      sombra: '#38bdf8',
      overlay: 'rgba(2,8,20,0.65)',
      display: 'rgba(10,20,35,0.92)',
      borda: '#38bdf8',
      expressao: '#7dd3fc',
      operador: '#082f49',
      igual: '#0369a1',
      numero: '#0f172a',
      imagem:
        'https://www.correiobraziliense.com.br/cbradar/wp-content/uploads/2026/03/Gemini_Generated_Image_7p0igt7p0igt7p0i-2-1.png'
    },

    vermelho: {
      logo: '#ef4444',
      sombra: '#ef4444',
      overlay: 'rgba(25,0,0,0.65)',
      display: 'rgba(25,5,5,0.92)',
      borda: '#ef4444',
      expressao: '#fca5a5',
      operador: '#7f1d1d',
      igual: '#dc2626',
      numero: '#1c1917',
      imagem:
        'https://i.pinimg.com/736x/be/4b/d1/be4bd1d81923974bf8c52e72619b5a4b.jpg'
    }
  };

  const cor = temas[tema];

  const bats = [
    useRef(new Animated.ValueXY({ x: 20, y: height + 80 })).current,
    useRef(new Animated.ValueXY({ x: 60, y: height + 120 })).current,
    useRef(new Animated.ValueXY({ x: 100, y: height + 50 })).current,
    useRef(new Animated.ValueXY({ x: 150, y: height + 150 })).current,
    useRef(new Animated.ValueXY({ x: 210, y: height + 90 })).current,
    useRef(new Animated.ValueXY({ x: 260, y: height + 130 })).current,
    useRef(new Animated.ValueXY({ x: 320, y: height + 70 })).current,
    useRef(new Animated.ValueXY({ x: 40, y: height + 180 })).current,
  ];

  const animarMorcegos = () => {
    bats.forEach((bat, i) => {
      bat.setValue({
        x: 20 + (i * 35),
        y: height + (Math.random() * 200)
      });
    });

    Animated.parallel(
      bats.map((bat, i) =>
        Animated.timing(bat, {
          toValue: {
            x: bat.x._value + ((Math.random() * 180) - 90),
            y: -60
          },
          duration: 3200 + (i * 250),
          useNativeDriver: false
        })
      )
    ).start();
  };

  const calcular = () => {
    try {
      const limpa = expressao.replace(/×/g, '*').replace(/÷/g, '/');
      const valor = eval(limpa);
      setResultado(String(valor));
      animarMorcegos();
    } catch {
      setResultado('Erro');
    }
  };

  const apertar = (tecla) => {
    if (tecla === 'C') {
      setExpressao('');
      setResultado('0');
      return;
    }

    if (tecla === '⌫') {
      setExpressao(expressao.slice(0, -1));
      return;
    }

    if (tecla === '=') {
      calcular();
      return;
    }

    setExpressao(expressao + tecla);
  };

  const teclado = [
    ['C', '⌫', '÷', '×'],
    ['7', '8', '9', '-'],
    ['4', '5', '6', '+'],
    ['1', '2', '3', '.'],
    ['0', '=']
  ];

  const estiloBotao = (item) => {
    if (item === '=') return { backgroundColor: cor.igual };
    if (item === 'C' || item === '⌫') return styles.limpar;
    if (['+', '-', '×', '÷'].includes(item)) {
      return { backgroundColor: cor.operador };
    }
    return { backgroundColor: cor.numero };
  };

  return (
    <ImageBackground
      source={{ uri: cor.imagem }}
      style={styles.background}
      resizeMode="cover"
    >
      <View
        style={[
          styles.overlay,
          { backgroundColor: cor.overlay }
        ]}
      />

      {bats.map((bat, index) => (
        <Animated.Text
          key={index}
          style={[
            styles.bat,
            {
              left: bat.x,
              top: bat.y
            }
          ]}
        >
          🦇
        </Animated.Text>
      ))}

      <View style={styles.container}>

        <Text
          style={[
            styles.logo,
            {
              color: cor.logo,
              textShadowColor: cor.sombra
            }
          ]}
        >
          BATCAVE SYSTEM
        </Text>

        <TouchableOpacity
          style={styles.themeButton}
          onPress={() =>
            setTema(tema === 'azul' ? 'vermelho' : 'azul')
          }
        >
          <Text style={styles.themeText}>
            ALTERAR TEMA
          </Text>
        </TouchableOpacity>

        <View
          style={[
            styles.display,
            {
              backgroundColor: cor.display,
              borderColor: cor.borda,
              shadowColor: cor.sombra
            }
          ]}
        >
          <Text
            style={[
              styles.expressao,
              { color: cor.expressao }
            ]}
          >
            {expressao || '0'}
          </Text>

          <Text style={styles.resultado}>
            {resultado}
          </Text>
        </View>

        <View style={styles.keyboard}>
          {teclado.map((linha, i) => (
            <View key={i} style={styles.row}>
              {linha.map((item) => (
                <TouchableOpacity
                  key={item}
                  style={[
                    styles.button,
                    estiloBotao(item),
                    item === '0' && styles.zeroButton
                  ]}
                  onPress={() => apertar(item)}
                >
                  <Text style={styles.buttonText}>
                    {item}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          ))}
        </View>

      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1
  },

  overlay: {
    ...StyleSheet.absoluteFillObject
  },

  container: {
    flex: 1,
    paddingTop: 45,
    paddingBottom: 20,
    paddingHorizontal: 14,
    justifyContent: 'space-between'
  },

  logo: {
    textAlign: 'center',
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: 3,
    textShadowRadius: 12
  },

  themeButton: {
    alignSelf: 'center',
    backgroundColor: '#111827',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 15,
    marginBottom: 10
  },

  themeText: {
    color: 'white',
    fontWeight: 'bold'
  },

  display: {
    minHeight: height * 0.23,
    borderRadius: 25,
    padding: 24,
    justifyContent: 'flex-end',
    borderWidth: 2,
    shadowRadius: 15
  },

  expressao: {
    fontSize: 24,
    textAlign: 'right'
  },

  resultado: {
    color: '#ffffff',
    fontSize: 58,
    fontWeight: 'bold',
    textAlign: 'right',
    marginTop: 10
  },

  keyboard: {
    gap: 12
  },

  row: {
    flexDirection: 'row',
    gap: 12
  },

  button: {
    flex: 1,
    height: 82,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 22
  },

  limpar: {
    backgroundColor: '#450a0a'
  },

  zeroButton: {
    flex: 2
  },

  buttonText: {
    color: 'white',
    fontSize: 30,
    fontWeight: '800'
  },

  bat: {
    position: 'absolute',
    fontSize: 48,
    zIndex: 1000
  }
});