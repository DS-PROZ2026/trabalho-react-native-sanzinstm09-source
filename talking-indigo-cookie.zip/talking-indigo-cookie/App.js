import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Animated,
  Dimensions,
  ImageBackground
} from 'react-native';

const { width, height } = Dimensions.get('window');

export default function App() {
  const [expressao, setExpressao] = useState('');
  const [resultado, setResultado] = useState('0');

  // 6 morcegos
  const bats = [
    useRef(new Animated.ValueXY({ x: +80, y: height * 1.0 })).current,
    useRef(new Animated.ValueXY({ x: +120, y: height * 1.4 })).current,
    useRef(new Animated.ValueXY({ x: -160, y: height * 1.2 })).current,
    useRef(new Animated.ValueXY({ x: -200, y: height * 0.65 })).current,
    useRef(new Animated.ValueXY({ x: -240, y: height * 1.5 })).current,
    useRef(new Animated.ValueXY({ x: -280, y: height * 1.7 })).current,
    useRef(new Animated.ValueXY({ x: -290, y: height * 1.7 })).current,
    useRef(new Animated.ValueXY({ x: -70, y: height * 1.7 })).current,
    useRef(new Animated.ValueXY({ x: -5,y: height * 1.7 })).current,
    useRef(new Animated.ValueXY({ x: -2, y: height * 1.7 })).current,
  ];

  const animarMorcegos = () => {
    bats.forEach((bat, i) => {
      bat.setValue({ x: -100 - (i * 50), y: height * (0.15 + i * 0.1) });
    });

    Animated.parallel(
      bats.map((bat, i) =>
        Animated.timing(bat, {
          toValue: {
            x: width + 100,
            y: height * (0.1 + (Math.random() * 0.7))
          },
          duration: 1000 + i * 200,
          useNativeDriver: false
        })
      )
    ).start();
  };

  const calcular = () => {
    try {
      const limpa = expressao.replace(/×/g, '*').replace(/÷/g, '/');
      const valor = eval(limpa);
      setResultado(String(valor));
      animarMorcegos();
    } catch {
      setResultado('Erro');
    }
  };

  const apertar = (tecla) => {
    if (tecla === 'C') {
      setExpressao('');
      setResultado('0');
      return;
    }

    if (tecla === '⌫') {
      setExpressao(expressao.slice(0, -1));
      return;
    }

    if (tecla === '=') {
      calcular();
      return;
    }

    setExpressao(expressao + tecla);
  };

  const teclado = [
    ['C', '⌫', '÷', '×'],
    ['7', '8', '9', '-'],
    ['4', '5', '6', '+'],
    ['1', '2', '3', '.'],
    ['0', '=']
  ];

  const tipoBotao = (t) => {
    if (t === '=') return styles.igual;
    if (t === 'C' || t === '⌫') return styles.limpar;
    if (['+', '-', '×', '÷'].includes(t)) return styles.operador;
    return styles.numero;
  };

  return (
    <ImageBackground
      source={{
        uri: 'https://www.correiobraziliense.com.br/cbradar/wp-content/uploads/2026/03/Gemini_Generated_Image_7p0igt7p0igt7p0i-2-1.png'
      }}
      style={styles.background}
      resizeMode="cover"
    >
      <View style={styles.overlay} />

      {/* morcegos */}
      {bats.map((bat, index) => (
        <Animated.Text
          key={index}
          style={[
            styles.bat,
            {
              left: bat.x,
              top: bat.y
            }
          ]}
        >
          🦇
        </Animated.Text>
      ))}

      <View style={styles.container}>

        <Text style={styles.logo}>BATCAVE SYSTEM</Text>

        <View style={styles.display}>
          <Text style={styles.expressao}>
            {expressao || '0'}
          </Text>

          <Text style={styles.resultado}>
            {resultado}
          </Text>
        </View>

        <View style={styles.keyboard}>
          {teclado.map((linha, i) => (
            <View key={i} style={styles.row}>
              {linha.map((item) => (
                <TouchableOpacity
                  key={item}
                  style={[
                    styles.button,
                    tipoBotao(item),
                    item === '0' && styles.zeroButton
                  ]}
                  onPress={() => apertar(item)}
                  activeOpacity={0.8}
                >
                  <Text style={styles.buttonText}>{item}</Text>
                </TouchableOpacity>
              ))}
            </View>
          ))}
        </View>

      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({

  background: {
    flex: 1
  },

  overlay: {
  ...StyleSheet.absoluteFillObject,
  backgroundColor: 'rgba(0,10,25,0.38)'
  },

  container: {
    flex: 1,
    paddingTop: 45,
    paddingBottom: 20,
    paddingHorizontal: 14,
    justifyContent: 'space-between'
  },

  logo: {
    color: '#38bdf8',
    textAlign: 'center',
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: 3,
    textShadowColor: '#38bdf8',
    textShadowRadius: 12
  },

  display: {
    minHeight: height * 0.23,
    backgroundColor: 'rgba(10,20,35,0.92)',
    borderRadius: 25,
    padding: 24,
    justifyContent: 'flex-end',
    borderWidth: 2,
    borderColor: '#38bdf8',
    shadowColor: '#38bdf8',
    shadowRadius: 15
  },

  expressao: {
    color: '#7dd3fc',
    fontSize: 24,
    textAlign: 'right'
  },

  resultado: {
    color: '#ffffff',
    fontSize: 58,
    fontWeight: 'bold',
    textAlign: 'right',
    marginTop: 10
  },

  keyboard: {
    gap: 12
  },

  row: {
    flexDirection: 'row',
    gap: 12
  },

  button: {
    flex: 1,
    height: 82,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 22
  },

  numero: {
    backgroundColor: '#0f172a'
  },

  operador: {
    backgroundColor: '#082f49'
  },

  limpar: {
    backgroundColor: '#450a0a'
  },

  igual: {
    backgroundColor: '#0369a1'
  },

  zeroButton: {
    flex: 2
  },

  buttonText: {
    color: 'white',
    fontSize: 30,
    fontWeight: '800'
  },

  bat: {
    position: 'absolute',
    fontSize: 34,
    zIndex: 1000
  }

});